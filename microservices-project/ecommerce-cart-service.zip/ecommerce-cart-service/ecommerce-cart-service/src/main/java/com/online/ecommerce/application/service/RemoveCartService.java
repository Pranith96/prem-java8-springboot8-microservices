package com.online.ecommerce.application.service;

public interface RemoveCartService {

	String removeItemFromCart(Integer itemId);

}
