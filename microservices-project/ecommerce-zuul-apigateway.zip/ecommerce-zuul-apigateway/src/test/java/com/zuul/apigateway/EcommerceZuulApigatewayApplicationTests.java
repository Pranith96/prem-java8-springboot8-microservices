package com.zuul.apigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceZuulApigatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
